package com.example.recipeapp_laila

import android.app.ProgressDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class View_Recipes : AppCompatActivity() {

    private var recipeDetails: List<Recipe_Details.information>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)
        val responseText = findViewById<View>(R.id.textView) as TextView

        get_Recipes(onResult = {
            recipeDetails = it
            Log.e("Data", recipeDetails.toString())

            var stringToBePritined:String? = "";
            for(recipe in recipeDetails!!){
                stringToBePritined = stringToBePritined +recipe.title + "\n"+recipe.author + "\n"+recipe.ingredients + "\n"+recipe.instructions+ "\n\n"
            }
            responseText.text= stringToBePritined
        } );
    }

    private fun get_Recipes(onResult: (List<Recipe_Details.information>?) -> Unit) {

        val apiInterface = API_Client().getClient()?.create(API_Interface::class.java)
        val progressDialog = ProgressDialog(this@View_Recipes)
        progressDialog.setMessage("Please wait")
        progressDialog.show()
        if (apiInterface != null) {
            apiInterface.getRecipies()?.enqueue(object : Callback<List<Recipe_Details.information>> {
                override fun onResponse(
                    call: Call<List<Recipe_Details.information>>,
                    response: Response<List<Recipe_Details.information>>
                ) {
                    onResult(response.body())
                    progressDialog.dismiss()

                }

                override fun onFailure(call: Call<List<Recipe_Details.information>>, t: Throwable) {
                    onResult(null)
                    progressDialog.dismiss()
                    Toast.makeText(applicationContext, ""+t.message, Toast.LENGTH_SHORT).show();
                }

            })
        }
    }
}