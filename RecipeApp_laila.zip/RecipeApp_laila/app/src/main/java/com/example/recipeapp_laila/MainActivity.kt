package com.example.recipeapp_laila

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val EditText_Title = findViewById<EditText>(R.id.EditText_Title)
        val EditText_Author = findViewById<EditText>(R.id.EditText_Author)
        val  EditText_Ingredents = findViewById<EditText>(R.id.EditText_Ingredents)
        val EditText_Instruction = findViewById<EditText>(R.id.EditText_Instruction)

        val Button_Save = findViewById<Button>(R.id.Button_Save)
        val Button_View = findViewById<Button>(R.id.Button_View)

        Button_Save.setOnClickListener {

            var f = Recipe_Details.information(
                EditText_Title.text.toString(),
                EditText_Author.text.toString(),
                EditText_Ingredents.text.toString(),
                EditText_Instruction.text.toString()
            )

            addDetelis(f, onResult = {
                EditText_Title.setText("")
                EditText_Author.setText("")
                EditText_Ingredents.setText("")
                EditText_Instruction.setText("")
                Toast.makeText(applicationContext, "Save Success!", Toast.LENGTH_SHORT).show();
            })

        }

        Button_View.setOnClickListener {

            intent = Intent(applicationContext, View_Recipes::class.java)
            startActivity(intent)

        }

    }

    fun addDetelis(userData: Recipe_Details.information, onResult: (Recipe_Details?) -> Unit) {
        val apiInterface = API_Client().getClient()?.create(API_Interface::class.java)

        val progressDialog = ProgressDialog(this@MainActivity)
        progressDialog.setMessage("Please wait")
        progressDialog.show()

        if (apiInterface != null) {
            apiInterface.addRecipie(userData).enqueue(object : Callback<Recipe_Details> {
                override fun onResponse(
                    call: Call<Recipe_Details>,
                    response: Response<Recipe_Details>
                ) {
                    onResult(response.body())
                    progressDialog.dismiss()
                }

                override fun onFailure(call: Call<Recipe_Details>, t: Throwable) {
                    onResult(null)
                    Toast.makeText(applicationContext, "Error!", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss()

                }
            })
        }
    }

}