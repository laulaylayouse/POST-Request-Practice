package com.example.postrequest_practice_laial

import com.google.gson.annotations.SerializedName


class Users {

    var data: List<User_Details>? = null

class User_Details {

    @SerializedName("name")
    var name: String? = null

    @SerializedName("location")
    var location: String? = null

    constructor(name: String?, location: String?) {
        this.name = name
        this.location = location
    }
}
}