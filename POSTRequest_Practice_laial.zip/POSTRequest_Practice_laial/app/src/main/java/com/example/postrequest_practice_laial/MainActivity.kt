package com.example.postrequest_practice_laial

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    lateinit var EditText_add_Name: EditText
    lateinit var EditText_add_Location: EditText
    lateinit var Button_Save: Button
    lateinit var Button_View: Button

    var name = ""
    var location = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        EditText_add_Name =findViewById(R.id.EditText_add_Name)
        EditText_add_Location =findViewById(R.id.EditText_add_Location)

        Button_Save =findViewById(R.id.Button_Save)
        Button_Save.setOnClickListener{

            name = EditText_add_Name.text.toString()
            location = EditText_add_Location.text.toString()

            if (name.isNotEmpty() && location.isNotEmpty())
            {
                var f = Users.User_Details(EditText_add_Name.text.toString(), EditText_add_Location.text.toString())

                addSingleuser(f, onResult = {
                    EditText_add_Name.setText("")
                    EditText_add_Location.setText("")
                    Toast.makeText(applicationContext, "Save Success!", Toast.LENGTH_SHORT).show();
                }


            }
            else
            {

                Toast.makeText(applicationContext, "Please Enter name & location correctly.", Toast.LENGTH_SHORT).show();

            }

        }

        Button_View =findViewById(R.id.Button_View)
        Button_View.setOnClickListener {

            intent = Intent(applicationContext, view_activity::class.java)
            startActivity(intent)
        }

    }

    }

//    private fun addSingleuser(onResult: () -> Unit) {
//
//        val apiInterface = API_Client().getClient()?.create(API_Interface::class.java)
//
//
//        if (apiInterface != null) {
//            apiInterface.add_User(Users.User_Details(name, location)).enqueue(object :Callback<Users.User_Details> {
//                override fun onResponse(
//                    call: Call<Users.User_Details>,
//                    response: Response<Users.User_Details>
//                ) {
//
//                    onResult()
//                }
//
//                override fun onFailure(call: Call<Users.User_Details>, t: Throwable) {
//                    onResult()
//                    Toast.makeText(applicationContext, "Error!", Toast.LENGTH_SHORT).show();
//
//                }
//            })
//        }

    private fun addSingleuser(f: Users.User_Details, onResult: () -> Unit) {

        val apiInterface = API_Client().getClient()?.create(API_Interface::class.java)
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please wait")
        progressDialog.show()

        if (apiInterface != null) {
            apiInterface.add_User(f).enqueue(object : Callback<Users.User_Details> {
                override fun onResponse(
                    call: Call<Users.User_Details>,
                    response: Response<Users.User_Details>
                ) {

                    onResult()
                    progressDialog.dismiss()
                }

                override fun onFailure(call: Call<Users.User_Details>, t: Throwable) {
                    onResult()
                    Toast.makeText(applicationContext, "Error!", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss()

                }
            })
        }
    }

}