package com.example.postrequest_practice_laial

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class view_activity : AppCompatActivity() {

    lateinit var Button_newuser: Button
//    lateinit var Recycler_View: RecyclerView

    val messages = arrayListOf<Users.User_Details>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.view_activity)

//        Recycler_View = findViewById(R.id.Recycler_View)
//        Recycler_View.adapter = RVAdapter(messages)
//        Recycler_View.layoutManager = LinearLayoutManager(applicationContext)

        Button_newuser = findViewById(R.id.Button_newuser)
        Button_newuser.setOnClickListener {

            intent = Intent(applicationContext, MainActivity::class.java)
            startActivity(intent)
        }

//        val apiInterface = API_Client().getClient()?.create(API_Interface::class.java)
//        val progressDialog = ProgressDialog(this)
//        progressDialog.setMessage("Please wait")
//        progressDialog.show()
//
//        if (apiInterface != null) {
//            apiInterface.get_User()?.enqueue(object :Callback<List<Users.User_Details>> {
//                override fun onResponse(
//                    call: Call<List<Users.User_Details>>,
//                    response: Response<List<Users.User_Details>>
//                ) {
//                    progressDialog.dismiss()
//                    for(User in response.body()!!){
////                        val name = User.name
////                        val location = User.location
////                        messages.add(Users.User_Details(name, location))
//                    }
////                    Recycler_View.adapter!!.notifyDataSetChanged()
//                }
//
//                override fun onFailure(call: Call<List<Users.User_Details>>, t: Throwable) {
//                    progressDialog.dismiss()
//                    Toast.makeText(applicationContext, ""+t.message, Toast.LENGTH_SHORT).show();
//                }
//
//            })
//        }


        val responseText = findViewById<View>(R.id.TextView_Data) as TextView
        val apiInterface = API_Client().getClient()?.create(API_Interface::class.java)
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please wait")
        progressDialog.show()
        if (apiInterface != null) {
            apiInterface.get_User()?.enqueue(object :Callback<List<Users.User_Details>> {
                override fun onResponse(
                    call: Call<List<Users.User_Details>>,
                    response: Response<List<Users.User_Details>>) {
                    progressDialog.dismiss()
                    var stringToBePritined:String? = "";
                    for(User in response.body()!!){
                        stringToBePritined = stringToBePritined +User.name+ "\n"+User.location + "\n"+"\n"
                    }
                    responseText.text= stringToBePritined
                }
                override fun onFailure(call: Call<List<Users.User_Details>>, t: Throwable) {
                    //  onResult(null)
                    progressDialog.dismiss()
                    Toast.makeText(applicationContext, ""+t.message, Toast.LENGTH_SHORT).show();
                }
            })
        }

    }

}