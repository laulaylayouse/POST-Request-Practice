package com.example.postrequest_practice_laial

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST

//https://dojo-recipes.herokuapp.com/recipes/

interface API_Interface {
    @Headers("Content-Type: application/json")
    @GET("/test/")
    fun get_User(): Call<List<Users.User_Details>>


    @Headers("Content-Type: application/json")
    @POST("/test/")
    fun add_User(@Body userData: Users.User_Details): Call<Users.User_Details>


}