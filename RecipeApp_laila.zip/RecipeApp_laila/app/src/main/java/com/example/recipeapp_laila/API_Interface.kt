package com.example.recipeapp_laila

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST

//https://dojo-recipes.herokuapp.com/recipes/

interface API_Interface {
    @Headers("Content-Type: application/json")
    @GET("/recipes/")
    fun getRecipies(): Call<List<Recipe_Details.information>>


    @Headers("Content-Type: application/json")
    @POST("/recipes/")
    fun addRecipie(@Body userData: Recipe_Details.information): Call<Recipe_Details>


}